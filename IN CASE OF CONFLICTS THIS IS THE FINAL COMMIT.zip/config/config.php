<?php


session_start();
ob_start();

//session_destroy();

$conn =  mysqli_connect("localhost","root","","hackathon_db");


?>